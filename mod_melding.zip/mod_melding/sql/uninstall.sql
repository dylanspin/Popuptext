DROP TABLE IF EXISTS `#__melding`;
