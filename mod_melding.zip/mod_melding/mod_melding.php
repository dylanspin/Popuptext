<?php
/**
 * @author - Dylan Spin
*/
  defined( '_JEXEC' ) or die('Restricted Access');

  require_once dirname(__FILE__) . '/helper.php';

  require JModuleHelper::getLayoutPath('mod_melding');

?>
